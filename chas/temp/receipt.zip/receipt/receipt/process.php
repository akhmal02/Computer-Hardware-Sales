<?php
session_start();
session_start();
include("../connect.php");

if (isset($_POST["add"])) {
    $receiptDate = $_POST["receiptDate"];
    $totalAmount = $_POST["totalAmount"];
    $custName = $_POST["custName"];
    $custAddress = $_POST["custAddress"];
    $payMethod = $_POST["payMethod"];
    $empID = $_POST["empID"];
    $prodID = $_POST["prodID"]; // Add this from form
    $qty = $_POST["qty"];       // Add this from form
    $price = $_POST["price"];   // Add this from form

    if (empty($custName) || empty($totalAmount) || empty($payMethod) || empty($prodID) || empty($qty) || empty($price)) {
        $_SESSION['status'] = "All fields are required.";
        header("Location: add_receipt.php");
        exit;
    }

    if (!is_numeric($totalAmount) || !is_numeric($empID) || !is_numeric($qty) || !is_numeric($price)) {
        $_SESSION['status'] = "Numeric fields must be valid numbers.";
        header("Location: add_receipt.php");
        exit;
    }

    // Start transaction
    oci_execute(oci_parse($conn, 'BEGIN AUTONOMOUS_TRANSACTION; END;')); // Enable autonomous transaction if needed

    // Insert into RECEIPT
    $sql_receipt = "INSERT INTO RECEIPT (RECEIPTID, RECEIPTDATE, TOTALAMOUNT, CUSTNAME, CUSTADDRESS, PAYMETHOD, EMPID) 
                    VALUES (receipt_seq.NEXTVAL, TO_DATE(:receiptDate, 'YYYY-MM-DD'), :totalAmount, :custName, :custAddress, :payMethod, :empID)
                    RETURNING RECEIPTID INTO :receiptID";
    $stid_receipt = oci_parse($conn, $sql_receipt);
    $newReceiptID = 0;
    oci_bind_by_name($stid_receipt, ':receiptDate', $receiptDate);
    oci_bind_by_name($stid_receipt, ':totalAmount', $totalAmount, -1, SQLT_NUM);
    oci_bind_by_name($stid_receipt, ':custName', $custName);
    oci_bind_by_name($stid_receipt, ':custAddress', $custAddress);
    oci_bind_by_name($stid_receipt, ':payMethod', $payMethod);
    oci_bind_by_name($stid_receipt, ':empID', $empID, -1, SQLT_NUM);
    oci_bind_by_name($stid_receipt, ':receiptID', $newReceiptID, -1, SQLT_INT);
    $result = oci_execute($stid_receipt);

    if ($result) {
        // Insert into RECEIPT_PRODUCT
        $sql_rp = "INSERT INTO RECEIPT_PRODUCT (REPPRODID, RECEIPTID, PRODID, QTY, PRICE) 
                   VALUES (repprod_seq.NEXTVAL, :receiptID, :prodID, :qty, :price)";
        $stid_rp = oci_parse($conn, $sql_rp);
        oci_bind_by_name($stid_rp, ':receiptID', $newReceiptID);
        oci_bind_by_name($stid_rp, ':prodID', $prodID);
        oci_bind_by_name($stid_rp, ':qty', $qty, -1, SQLT_NUM);
        oci_bind_by_name($stid_rp, ':price', $price, -1, SQLT_NUM);
        $rp_result = oci_execute($stid_rp);

        if ($rp_result) {
            oci_commit($conn); // Commit transaction
            $_SESSION['status'] = "Receipt and products added successfully.";
        } else {
            oci_rollback($conn); // Rollback on failure
            $e = oci_error($stid_rp);
            $_SESSION['status'] = "Error adding receipt product: " . htmlentities($e['message']);
        }
    } else {
        oci_rollback($conn);
        $e = oci_error($stid_receipt);
        $_SESSION['status'] = "Error adding receipt: " . htmlentities($e['message']);
    }

    oci_free_statement($stid_receipt);
    oci_free_statement($stid_rp);
    oci_close($conn);
    header("Location: view_receipts.php");
    exit;
}

} elseif (isset($_POST["edit"])) {
    // Retrieve form data for updating a receipt
    $id = $_POST["id"];
    $receiptDate = $_POST["receiptDate"];
    $totalAmount = $_POST["totalAmount"];
    $custName = $_POST["custName"];
    $custAddress = $_POST["custAddress"];
    $payMethod = $_POST["payMethod"];
    $empID = $_POST["empID"];

    // Basic validation
    if (empty($custName) || empty($totalAmount) || empty($payMethod)) {
        $_SESSION['status'] = "Customer Name, Total Amount, and Payment Method are required.";
        header("Location: update.php?id=$id");
        exit;
    }

    // Validate numeric fields
    if (!is_numeric($totalAmount) || !is_numeric($empID)) {
        $_SESSION['status'] = "Total Amount and Employee ID must be valid numbers.";
        header("Location: update.php?id=$id");
        exit;
    }

    // Prepare the UPDATE query
    $sql = "UPDATE RECEIPT SET 
            RECEIPTDATE = TO_DATE(:receiptDate, 'YYYY-MM-DD'), 
            TOTALAMOUNT = :totalAmount, 
            CUSTNAME = :custName, 
            CUSTADDRESS = :custAddress, 
            PAYMETHOD = :payMethod, 
            EMPID = :empID 
            WHERE RECEIPTID = :receiptID";

    $stid = oci_parse($conn, $sql);
    if (!$stid) {
        $e = oci_error($conn);
        $_SESSION['status'] = "Error parsing query: " . htmlentities($e['message']);
        header("Location: update.php?id=$id");
        exit;
    }

    // Bind parameters
    oci_bind_by_name($stid, ':receiptID', $id);
    oci_bind_by_name($stid, ':receiptDate', $receiptDate);
    oci_bind_by_name($stid, ':totalAmount', $totalAmount, -1, SQLT_NUM);
    oci_bind_by_name($stid, ':custName', $custName);
    oci_bind_by_name($stid, ':custAddress', $custAddress);
    oci_bind_by_name($stid, ':payMethod', $payMethod);
    oci_bind_by_name($stid, ':empID', $empID, -1, SQLT_NUM);

    // Execute the query
    $result = oci_execute($stid);
    if ($result) {
        $_SESSION['status'] = "Receipt updated successfully.";
    } else {
        $e = oci_error($stid);
        $_SESSION['status'] = "Error updating receipt: " . htmlentities($e['message']);
        header("Location: update.php?id=$id");
    }

    // Clean up
    oci_free_statement($stid);
    oci_close($conn);
    header("Location: view_receipt.php");
    exit;

} else {
    $_SESSION['status'] = "Invalid request.";
    header("Location: view_receipt.php");
    exit;
}
?>